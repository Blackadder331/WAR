# CardWarGame
Card War Game build with pure JavaScript, CSS and HTML
@Author Kfir Goldfarb 2019
Main file for this project is index.html file, the JavaScript for this project is mainJS.js file and the CSS gor this project is mainCSS.css file
how I build video: https://www.youtube.com/watch?v=v8a63oXxnc4&feature=youtu.be
